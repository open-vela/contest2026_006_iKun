/**
 * 手势工具模块
 * 提供边缘滑动返回手势判断
 */

// 边缘判断阈值：触摸开始位置 x <= 50px 视为边缘
const EDGE_THRESHOLD = 50

// 滑动距离阈值：deltaX >= 80px 视为有效滑动
const SWIPE_THRESHOLD = 80

// 方向比例：deltaX > abs(deltaY) * 1.2 视为横向滑动
const DIRECTION_RATIO = 1.2

/**
 * 判断是否为有效的边缘右滑手势
 * @param {number} startX 触摸开始 X 坐标
 * @param {number} startY 触摸开始 Y 坐标
 * @param {number} currentX 当前 X 坐标
 * @param {number} currentY 当前 Y 坐标
 * @returns {boolean}
 */
export function isEdgeSwipeRight(startX, startY, currentX, currentY) {
  // 必须从左侧边缘开始
  if (startX > EDGE_THRESHOLD) return false

  const deltaX = currentX - startX
  const deltaY = currentY - startY

  // 必须向右滑动足够距离
  if (deltaX < SWIPE_THRESHOLD) return false

  // 横向移动必须明显大于纵向移动
  if (deltaX <= Math.abs(deltaY) * DIRECTION_RATIO) return false

  return true
}
