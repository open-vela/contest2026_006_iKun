/**
 * 本地存储模块
 * 使用 @system.storage 实现离线数据持久化
 * 内存缓存 + system.storage 持久化
 */

import storage from '@system.storage'
import { courses, exams, tasks } from './data'

const STORAGE_KEYS = {
  COURSES: 'campus_courses',
  EXAMS: 'campus_exams',
  TASKS: 'campus_tasks'
}

// 内存缓存
let courseCache = []
let examCache = []
let taskCache = []
let storageReady = false

/**
 * 初始化存储
 * 从 system.storage 读取数据，如果不存在则使用 Mock数据
 * @returns {Promise}
 */
export function initStorage() {
  return new Promise((resolve) => {
    let loaded = 0
    const total = 3

    const checkComplete = () => {
      loaded++
      if (loaded >= total) {
        storageReady = true
        resolve()
      }
    }

    // 读取课程
    storage.get({
      key: STORAGE_KEYS.COURSES,
      success: function (data) {
        try {
          courseCache = data ? JSON.parse(data) : [...courses]
        } catch (e) {
          console.error('Failed to parse courses:', e)
          courseCache = [...courses]
        }
        checkComplete()
      },
      fail: function (data, code) {
        console.error('Failed to get courses:', code)
        courseCache = [...courses]
        checkComplete()
      }
    })

    // 读取考试
    storage.get({
      key: STORAGE_KEYS.EXAMS,
      success: function (data) {
        try {
          examCache = data ? JSON.parse(data) : [...exams]
        } catch (e) {
          console.error('Failed to parse exams:', e)
          examCache = [...exams]
        }
        checkComplete()
      },
      fail: function (data, code) {
        console.error('Failed to get exams:', code)
        examCache = [...exams]
        checkComplete()
      }
    })

    // 读取任务
    storage.get({
      key: STORAGE_KEYS.TASKS,
      success: function (data) {
        try {
          taskCache = data ? JSON.parse(data) : [...tasks]
        } catch (e) {
          console.error('Failed to parse tasks:', e)
          taskCache = [...tasks]
        }
        // 如果是首次运行（没有存储数据），写入 Mock 数据
        if (!data) {
          saveTasksToStorage()
        }
        checkComplete()
      },
      fail: function (data, code) {
        console.error('Failed to get tasks:', code)
        taskCache = [...tasks]
        saveTasksToStorage()
        checkComplete()
      }
    })
  })
}

/**
 * 保存任务到 system.storage
 */
function saveTasksToStorage() {
  storage.set({
    key: STORAGE_KEYS.TASKS,
    value: JSON.stringify(taskCache),
    success: function () {
      console.log('Tasks saved to storage')
    },
    fail: function (data, code) {
      console.error('Failed to save tasks:', code)
    }
  })
}

/**
 * 获取课程数据
 * @returns {Array}
 */
export function getCourses() {
  return courseCache
}

/**
 * 获取考试数据
 * @returns {Array}
 */
export function getExams() {
  return examCache
}

/**
 * 获取待办数据
 * @returns {Array}
 */
export function getTasks() {
  return taskCache
}

/**
 * 更新任务状态并持久化
 * @param {string} taskId
 * @param {boolean} finished
 * @returns {Promise<boolean>}
 */
export function updateTaskStatus(taskId, finished) {
  return new Promise((resolve, reject) => {
    const index = taskCache.findIndex(t => t.id === taskId)
    if (index === -1) {
      reject(new Error('Task not found'))
      return
    }

    // 更新缓存
    taskCache[index].finished = finished

    // 持久化到 storage
    storage.set({
      key: STORAGE_KEYS.TASKS,
      value: JSON.stringify(taskCache),
      success: function () {
        console.log('Task status updated and saved:', taskId, finished)
        resolve(true)
      },
      fail: function (data, code) {
        console.error('Failed to save task status:', code)
        reject(new Error('Failed to save task status'))
      }
    })
  })
}

/**
 * 重置为 Mock 数据（调试用）
 * @returns {Promise}
 */
export function resetToMockData() {
  return new Promise((resolve) => {
    courseCache = [...courses]
    examCache = [...exams]
    taskCache = [...tasks]

    let saved = 0
    const total = 3

    const checkComplete = () => {
      saved++
      if (saved >= total) {
        resolve()
      }
    }

    storage.set({
      key: STORAGE_KEYS.COURSES,
      value: JSON.stringify(courseCache),
      success: checkComplete,
      fail: checkComplete
    })

    storage.set({
      key: STORAGE_KEYS.EXAMS,
      value: JSON.stringify(examCache),
      success: checkComplete,
      fail: checkComplete
    })

    storage.set({
      key: STORAGE_KEYS.TASKS,
      value: JSON.stringify(taskCache),
      success: checkComplete,
      fail: checkComplete
    })
  })
}
